package com.lite.tvlauncher;

import android.app.Activity;
import android.content.*;
import android.content.pm.*;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.text.Collator;
import java.util.*;

public class MainActivity extends Activity {

    static class App {
        String label, pkg; Intent intent; Drawable icon;
    }

    private final List<App> apps = new ArrayList<App>();
    private AppAdapter adapter;
    private GridView grid;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private final BroadcastReceiver pkgReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { loadApps(); }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        grid = (GridView) findViewById(R.id.grid);
        adapter = new AppAdapter();
        grid.setAdapter(adapter);

        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                try { startActivity(apps.get(pos).intent); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "Không mở được", Toast.LENGTH_SHORT).show(); }
            }
        });
        grid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            public boolean onItemLongClick(AdapterView<?> p, View v, int pos, long id) {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + apps.get(pos).pkg));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try { startActivity(i); } catch (Exception ignored) {}
                return true;
            }
        });

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addDataScheme("package");
        registerReceiver(pkgReceiver, f);

        loadApps();
    }

    /** Load apps on a background thread so the UI thread stays free on weak SoCs. */
    private void loadApps() {
        new Thread(new Runnable() {
            public void run() {
                PackageManager pm = getPackageManager();
                Intent q = new Intent(Intent.ACTION_MAIN, null);
                q.addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> list = pm.queryIntentActivities(q, 0);
                final List<App> out = new ArrayList<App>();
                for (ResolveInfo ri : list) {
                    String pkg = ri.activityInfo.packageName;
                    if (pkg.equals(getPackageName())) continue;
                    App a = new App();
                    a.pkg = pkg;
                    a.label = String.valueOf(ri.loadLabel(pm));
                    a.icon = ri.loadIcon(pm);
                    a.intent = new Intent(Intent.ACTION_MAIN)
                            .addCategory(Intent.CATEGORY_LAUNCHER)
                            .setClassName(pkg, ri.activityInfo.name)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                    out.add(a);
                }
                final Collator c = Collator.getInstance();
                Collections.sort(out, new Comparator<App>() {
                    public int compare(App x, App y) { return c.compare(x.label, y.label); }
                });
                ui.post(new Runnable() {
                    public void run() {
                        apps.clear(); apps.addAll(out);
                        adapter.notifyDataSetChanged();
                        if (grid.getSelectedItemPosition() < 0 && !apps.isEmpty()) grid.setSelection(0);
                    }
                });
            }
        }).start();
    }

    @Override public void onBackPressed() { grid.setSelection(0); }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        grid.setSelection(0);
    }

    @Override protected void onDestroy() {
        unregisterReceiver(pkgReceiver);
        super.onDestroy();
    }

    private class AppAdapter extends BaseAdapter {
        public int getCount() { return apps.size(); }
        public Object getItem(int p) { return apps.get(p); }
        public long getItemId(int p) { return p; }
        public View getView(int p, View v, ViewGroup parent) {
            Holder h;
            if (v == null) {
                v = getLayoutInflater().inflate(R.layout.item_app, parent, false);
                h = new Holder();
                h.icon = (ImageView) v.findViewById(R.id.icon);
                h.label = (TextView) v.findViewById(R.id.label);
                v.setTag(h);
            } else h = (Holder) v.getTag();
            App a = apps.get(p);
            h.icon.setImageDrawable(a.icon);
            h.label.setText(a.label);
            return v;
        }
    }
    static class Holder { ImageView icon; TextView label; }
}

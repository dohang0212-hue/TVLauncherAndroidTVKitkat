TV Launcher nhe - Android 4.4 (API 19), ARMv7a (Amlogic)
- Khong dung thu vien ngoai, khong co ma native -> chay tot tren armeabi-v7a.
- Mo bang Android Studio -> Build > Build APK(s). Hoac: gradle assembleRelease
- Cai: adb install app-release.apk (hoac copy vao USB)
- Dat lam mac dinh: bam Home -> chon "TV Launcher" -> "Luon luon".
Dieu khien: D-pad di chuyen, OK mo app, giu OK xem thong tin/go app, Back ve o dau.

package com.example.tvclock;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends Activity {

    // {tên, vĩ độ, kinh độ}
    private static final String[][] CITIES = {
            {"Hưng Yên", "20.6464", "106.0511"},
            {"Hà Nội", "21.0285", "105.8542"},
            {"Hải Phòng", "20.8449", "106.6881"},
            {"Huế", "16.4637", "107.5909"},
            {"Đà Nẵng", "16.0544", "108.2022"},
            {"TP. Hồ Chí Minh", "10.8231", "106.6297"},
            {"Cần Thơ", "10.0452", "105.7469"}
    };

    private static final long WEATHER_REFRESH_MS = 30 * 60 * 1000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Locale vi = new Locale("vi", "VN");

    private TextView tvTime, tvDate, tvCity, tvIcon, tvTemp, tvDesc, tvDetail;
    private LinearLayout forecast;
    private int cityIndex = 0;
    private SharedPreferences prefs;

    private final Runnable clockTick = new Runnable() {
        @Override public void run() {
            Date now = new Date();
            tvTime.setText(new SimpleDateFormat("HH:mm", vi).format(now));
            String date = new SimpleDateFormat("EEEE, dd/MM/yyyy", vi).format(now);
            tvDate.setText(date.substring(0, 1).toUpperCase(vi) + date.substring(1));
            handler.postDelayed(this, 1000);
        }
    };

    private final Runnable weatherTick = new Runnable() {
        @Override public void run() {
            loadWeather();
            handler.postDelayed(this, WEATHER_REFRESH_MS);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);

        tvTime = (TextView) findViewById(R.id.tvTime);
        tvDate = (TextView) findViewById(R.id.tvDate);
        tvCity = (TextView) findViewById(R.id.tvCity);
        tvIcon = (TextView) findViewById(R.id.tvIcon);
        tvTemp = (TextView) findViewById(R.id.tvTemp);
        tvDesc = (TextView) findViewById(R.id.tvDesc);
        tvDetail = (TextView) findViewById(R.id.tvDetail);
        forecast = (LinearLayout) findViewById(R.id.forecast);

        prefs = getSharedPreferences("tvclock", MODE_PRIVATE);
        cityIndex = Math.min(prefs.getInt("city", 0), CITIES.length - 1);
        tvCity.setText("📍 " + CITIES[cityIndex][0]);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(clockTick);
        handler.post(weatherTick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacksAndMessages(null);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                changeCity(1);
                return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                changeCity(-1);
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                handler.removeCallbacks(weatherTick);
                handler.post(weatherTick);
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void changeCity(int delta) {
        cityIndex = (cityIndex + delta + CITIES.length) % CITIES.length;
        prefs.edit().putInt("city", cityIndex).apply();
        tvCity.setText("📍 " + CITIES[cityIndex][0]);
        handler.removeCallbacks(weatherTick);
        handler.post(weatherTick);
    }

    // ---------------- Thời tiết (Open-Meteo, không cần API key) ----------------

    private void loadWeather() {
        final int idx = cityIndex;
        tvDetail.setText("Đang cập nhật...");
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    String url = "https://api.open-meteo.com/v1/forecast"
                            + "?latitude=" + CITIES[idx][1] + "&longitude=" + CITIES[idx][2]
                            + "&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m"
                            + "&daily=weather_code,temperature_2m_max,temperature_2m_min"
                            + "&timezone=auto&forecast_days=4";
                    final JSONObject json = new JSONObject(httpGet(url));
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (idx == cityIndex) showWeather(json);
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            tvDetail.setText("Không tải được thời tiết. Kiểm tra mạng rồi nhấn OK.");
                        }
                    });
                }
            }
        }).start();
    }

    private String httpGet(String urlStr) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(urlStr).openConnection();
        if (conn instanceof HttpsURLConnection) {
            ((HttpsURLConnection) conn).setSSLSocketFactory(new Tls12SocketFactory());
        }
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        InputStream in = conn.getInputStream();
        BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line);
        r.close();
        conn.disconnect();
        return sb.toString();
    }

    private void showWeather(JSONObject json) {
        try {
            JSONObject cur = json.getJSONObject("current");
            String[] d = describe(cur.getInt("weather_code"));
            tvIcon.setText(d[0]);
            tvTemp.setText(Math.round(cur.getDouble("temperature_2m")) + "°C");
            tvDesc.setText(d[1]);
            tvDetail.setText("Độ ẩm " + cur.getInt("relative_humidity_2m") + "%   •   Gió "
                    + Math.round(cur.getDouble("wind_speed_10m")) + " km/h");

            JSONObject daily = json.getJSONObject("daily");
            JSONArray days = daily.getJSONArray("time");
            JSONArray codes = daily.getJSONArray("weather_code");
            JSONArray max = daily.getJSONArray("temperature_2m_max");
            JSONArray min = daily.getJSONArray("temperature_2m_min");

            forecast.removeAllViews();
            SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            SimpleDateFormat out = new SimpleDateFormat("EEE dd/MM", vi);
            for (int i = 1; i < days.length(); i++) { // bỏ hôm nay, hiện 3 ngày tới
                LinearLayout col = new LinearLayout(this);
                col.setOrientation(LinearLayout.VERTICAL);
                col.setGravity(Gravity.CENTER_HORIZONTAL);
                col.setLayoutParams(new LinearLayout.LayoutParams(0,
                        LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

                String label;
                try { label = out.format(in.parse(days.getString(i))); }
                catch (Exception e) { label = days.getString(i); }

                col.addView(makeText(label, 18, 0xFFB8C7DC));
                col.addView(makeText(describe(codes.getInt(i))[0], 36, 0xFFFFFFFF));
                col.addView(makeText(Math.round(max.getDouble(i)) + "° / "
                        + Math.round(min.getDouble(i)) + "°", 20, 0xFFFFFFFF));
                forecast.addView(col);
            }
        } catch (Exception e) {
            tvDetail.setText("Dữ liệu thời tiết không hợp lệ.");
        }
    }

    private TextView makeText(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    /** Mã thời tiết WMO -> {biểu tượng, mô tả tiếng Việt} */
    private static String[] describe(int c) {
        if (c == 0) return new String[]{"☀️", "Trời quang"};
        if (c <= 2) return new String[]{"⛅", "Ít mây"};
        if (c == 3) return new String[]{"☁️", "Nhiều mây"};
        if (c == 45 || c == 48) return new String[]{"🌫️", "Sương mù"};
        if (c >= 51 && c <= 57) return new String[]{"🌦️", "Mưa phùn"};
        if (c >= 61 && c <= 67) return new String[]{"🌧️", "Mưa"};
        if (c >= 71 && c <= 77) return new String[]{"❄️", "Tuyết"};
        if (c >= 80 && c <= 82) return new String[]{"🌧️", "Mưa rào"};
        if (c >= 95) return new String[]{"⛈️", "Dông"};
        return new String[]{"🌡️", "Không rõ"};
    }
}

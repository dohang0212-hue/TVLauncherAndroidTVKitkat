package com.example.tvclock;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/** Android 4.4 mặc định tắt TLS 1.2, lớp này bật lại để gọi được API HTTPS. */
public class Tls12SocketFactory extends SSLSocketFactory {
    private final SSLSocketFactory base;

    public Tls12SocketFactory() throws Exception {
        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(null, null, null);
        base = ctx.getSocketFactory();
    }

    private Socket patch(Socket s) {
        if (s instanceof SSLSocket) {
            ((SSLSocket) s).setEnabledProtocols(new String[]{"TLSv1", "TLSv1.1", "TLSv1.2"});
        }
        return s;
    }

    @Override public String[] getDefaultCipherSuites() { return base.getDefaultCipherSuites(); }
    @Override public String[] getSupportedCipherSuites() { return base.getSupportedCipherSuites(); }
    @Override public Socket createSocket(Socket s, String h, int p, boolean a) throws IOException { return patch(base.createSocket(s, h, p, a)); }
    @Override public Socket createSocket(String h, int p) throws IOException { return patch(base.createSocket(h, p)); }
    @Override public Socket createSocket(String h, int p, InetAddress la, int lp) throws IOException { return patch(base.createSocket(h, p, la, lp)); }
    @Override public Socket createSocket(InetAddress h, int p) throws IOException { return patch(base.createSocket(h, p)); }
    @Override public Socket createSocket(InetAddress h, int p, InetAddress la, int lp) throws IOException { return patch(base.createSocket(h, p, la, lp)); }
}
